<?php
   
    function findUserByLogin($login){
        
        global $connect;
        
        $statement=$connect->prepare("SELECT username FROM login WHERE username=?");
        
        $statement->execute(array($login));
        
        $count=$statement->rowCount();
        
        return $count;
        
    }
	 function validateMail($mailadr)
 {

if (preg_match('/^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/  ',
$mailadr)) {
 return true;
} else {
 return false;
}
 }
	

   
	
?>