<?php
ob_start();
    
//CONX BD
$host = "localhost";  
 $username = "id12823880_user";  
 $password = "password";  
 $database = "id12823880_checommerce";  
 $message = "";   

   try  
 {  
   
       $connect= new PDO("mysql:host=$host; dbname=$database", $username, $password);  
      $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    }
    catch(Exception $e)
    {
       die ($e->getMessage()) ;
    }
 
	  $id=$_GET['id'];
	  echo $id;

	$requete='DELETE FROM panier where idproduit=" '.$id.' " ';			
	$param=array($id);	
	$resultat =$connect->prepare($requete);	
	$resultat->execute($param);	

 header('Location: ' . $_SERVER['HTTP_REFERER']);
            exit();
	
?>