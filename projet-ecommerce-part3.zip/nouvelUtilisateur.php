<?php
session_start();
?>
<html>
	
	 <head>
        <meta charset="utf-8">
       
        <link rel="stylesheet" href="css/bootstrap.min.css" />
		 
		<link rel="stylesheet" href="css/newstyle2.css" media="screen" type="text/css" />
    </head>
<?php
	 $host = "localhost";  
 $username = "id12823880_user";  
 $password = "password";  
 $database = "id12823880_checommerce";  
 $message = "";  
 
    try
    { $connect = new PDO("mysql:host=$host; dbname=$database", $username, $password);  
      $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    }
    catch(Exception $e)
    {
       die ($e->getMessage()) ;
    }
	
	include 'fonction.php'; 
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		
		$validationErrors = array();
		
		$login = $_POST['login'];
        
		
		$pwd1 = $_POST['pwd1'];
		
		$pwd2 = $_POST['pwd2'];
		
		$email = $_POST['email'];
        $nom = $_POST['nom'];
         $prenom = $_POST['prenom'];
         $tel = $_POST['tel'];
		$_SESSION['email']=$email;

			if (isset($login)) {
				
				$filtredLogin = filter_var($login, FILTER_SANITIZE_STRING);
				
				if (strlen($filtredLogin) < 4) {
					
					$validationErrors[] = "Erreur de validation: Le login doit contenir au moins 4 caractères";
				
				}
			}

			if (isset($pwd1) && isset($pwd2)) {
				
				if (empty($pwd1)) {
					
					$validationErrors[] = "Erreur de validation: Le mot ne doit pas être vide!";
				}

				if (md5($pwd1) !== md5($pwd2)) {
					
					$validationErrors[] = "Erreur de validation: Les deux mots de passe ne sont pas identiques";
				}
			}

			if (isset($email)) {
				   $filtredEmail = filter_var($email, FILTER_SANITIZE_EMAIL);
				
				if (filter_var($filtredEmail, FILTER_VALIDATE_EMAIL) != true) {
					
					$validationErrors[] = "Erreur de validation: Email non valid";
			}
			}

		if (empty($validationErrors)) {
			
			if (findUserByLogin($login) == 0) {
				
				$stmt = $connect->prepare('INSERT INTO login(username, password,email,nom, prenom,tel)
										VALUES (:pLogin,:pPwd,:pEmail,:pNom,:pPrenom,:pTel)');
										
				$stmt->execute(array(
				
						'pLogin' 	=> $login,
						'pPwd' 		=> ($pwd1),
						'pEmail' 	=> $email,
						'pNom'		=>$nom,
                         'pPrenom'		=>$prenom,
                'pTel'	=>$tel)
				);
				
				$succesMsg = "Félicitation , vous avez créer votre nouveau compte";
				
			} else if(findUserByLogin($login) >0){

				$validationErrors[] = 'Désolé ce login existe déja';
				
			}else if(findUserByEmail($email) >0){

				$validationErrors[] = 'Désolé cet Email existe déja';
			}

		}
	}
	
	
?>

<!DOCTYPE html>
<html>
    <head>
    <title>C & H</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="familycss.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">
<link rel="stylesheet" href="css.css">
<link rel="stylesheet" href="font-awesome.min.css">
<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='jss.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
<?php 
 echo' <div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" ><img src="img2/logo-carousel/LL.png" style="width:100px;height:70px;margin-left:10px;"></a>
  
      <a href="index.php?logout=true" class="w3-bar-item w3-button" style="padding:22px;"><i class=""></i> BACK</a>
    
        
</form>
        



       
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
        
  </div>
</div> ';?>

<div class="container" style="width:70%;margin-top:40px;border-radius:10px;background-color:#333;height:auto;">
                
               <br> <h3 style="color:#DAA520;">Créer Votre Compte </h3><br />  
                <form method="post">  
                      
                     <input 
					 pattern=".{4,}"
					
							title="Le login doit contenir au moins 4 caractères"
							class=""
							type="text"
							name="login"
							autocomplete="off"
							placeholder="Tapez votre nom d'utilisateur"
							required="required"
					 style="border-radius:5px;width:45%;height:40px;margin-bottom:30px;margin-top:30px;" />  
                      
                     <input 
					 pattern=".{4,}"
					
							title="Le nom doit contenir au moins 4 caractères"
							class=""
							type="text"
							name="nom"
							autocomplete="off"
							placeholder="Tapez votre nom"
							required="required"
					 style="border-radius:5px;width:45%;height:40px;margin-bottom:30px;margin-top:30px;" />  
                     <br />  
                     <input 
					 pattern=".{4,}"
					
							title="Le prenom doit contenir au moins 4 caractères"
							class=""
							type="text"
							name="prenom"
							autocomplete="off"
							placeholder="Tapez votre prenom"
							required="required"
					 style="border-radius:5px;width:45%;height:40px;margin-bottom:30px;margin-top:30px;" />  
                      
                     <input 
					 pattern=".{10,}"
					
							title="Le tel doit contenir au moins 10 caractères"
							class=""
							type="text"
							name="tel"
							autocomplete="off"
							placeholder="Tapez votre numero de telephone"
							required="required"
					 style="border-radius:5px;width:45%;height:40px;margin-bottom:30px;margin-top:30px;" />  
                     <br />  
                      <input 
					 class=""
							type="text"
							name="email"
							placeholder="Tapez votre Email"
					 style="border-radius:5px;width:70%;height:40px;margin-bottom:30px;" />  
					 
                     <br /> 
                     <input 
					 minlength=4
							class=""
							type="password"
							name="pwd1"
							autocomplete="new-password"
							placeholder="Tapez votre mot de passe"
							required
					 style="border-radius:5px;width:70%;height:40px;margin-bottom:30px;" />  
                     <br />  
					   
                     <input 
					 minlength=4
							class=""
							type="password"
							name="pwd2"
							autocomplete="new-password"
							placeholder="Retapez votre mot de passe "
							required
					 style="border-radius:5px;width:70%;height:40px;margin-bottom:30px;" />  
					 
                     <br />  
					  
                     <input type="submit" name="update" style="color:white;background-color:#DAA520;border-color:#DAA520;border-radius:10px;width:100px;height:30px;border:0px;" value="Enregistrer" />  
                </form> 
              
<div class="text-danger"	>			
				<?php
				
					if (isset($validationErrors) && !empty($validationErrors)) {
					    
						foreach ($validationErrors as $error) {
						    
							echo '<div class="msg error">' . $error . '</div>';
							
						}
					}

					if (!empty($succesMsg)) {
						
						echo '<div class="msg succes">' . $succesMsg . '</div>';
						
						exit();
					}
			?>
           </div>
           </div></body></html>